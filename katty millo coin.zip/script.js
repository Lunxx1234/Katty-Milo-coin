function toggleMobileNav() {
  document.getElementById("nav-links").classList.toggle("active");
}

function copyCA() {
  const caText = document.getElementById("ca-text").textContent;
  navigator.clipboard.writeText(caText)
    .then(() => {
      alert("Contract Address copied!");
    })
    .catch(err => {
      console.error("Failed to copy CA: ", err);
    });
}